from PyQt6.QtWidgets import QDialog, QLabel, QVBoxLayout, QPushButton, QMessageBox, QInputDialog, QApplication
from models import session, User, Student, Grades
import openpyxl

class Teacher(QDialog):
    def __init__(self, user):
        super().__init__()

        self.setWindowTitle('Учёт студента в вузе - Режим преподавателя')
        self.setFixedSize(400, 200)
        self.adjustSize()
        self.move_center()

        layout = QVBoxLayout()

        welcome_label = QLabel(f"Добро пожаловать, {user.username}!")
        self.search_student_btn = QPushButton("Поиск студента")
        self.delete_student_btn = QPushButton("Удалить студента")
        self.edit_student_btn = QPushButton("Редактировать данные студента")
        self.edit_grades_btn = QPushButton("Редактировать оценки студента")
        self.import_grades_btn = QPushButton("Импорт в Excel")

        self.delete_student_btn.clicked.connect(self.delete_student)
        self.edit_student_btn.clicked.connect(self.edit_student)
        self.edit_grades_btn.clicked.connect(self.edit_grades)
        self.search_student_btn.clicked.connect(self.search_student)
        self.import_grades_btn.clicked.connect(self.import_grades_to_excel)

        layout.addWidget(welcome_label)
        layout.addWidget(self.delete_student_btn)
        layout.addWidget(self.edit_student_btn)
        layout.addWidget(self.search_student_btn)
        layout.addWidget(self.edit_grades_btn)
        layout.addWidget(self.import_grades_btn)

        self.setLayout(layout)


    def show_message(self, title, message):
        msg_box = QMessageBox()
        msg_box.setIcon(QMessageBox.Icon.Information)
        msg_box.setWindowTitle(title)
        msg_box.setText(message)
        msg_box.exec()

    def show_error_message(self, title, message):
        msg_box = QMessageBox()
        msg_box.setIcon(QMessageBox.Icon.Critical)
        msg_box.setWindowTitle(title)
        msg_box.setText(message)
        msg_box.exec()

    def move_center(self):
        frame_gm = self.frameGeometry()
        screen = QApplication.primaryScreen().availableGeometry()
        frame_gm.moveCenter(screen.center())
        self.move(frame_gm.topLeft())

    def delete_student(self):
        students = session.query(Student).all()

        if students:
            student_names = [student.name for student in students]
            student_name, ok = QInputDialog.getItem(self, "Удалить студента", "Выберите студента:", student_names, 0,
                                                    False)

            if ok and student_name:
                try:
                    student_to_delete = session.query(Student).filter_by(name=student_name).first()

                    if student_to_delete:
                        session.delete(student_to_delete)
                        session.commit()
                        self.show_message("Удалить студента", f"Студент {student_name} успешно удален.")
                    else:
                        self.show_error_message("Ошибка", f"Студент {student_name} не найден.")
                except Exception as e:
                    session.rollback()
                    self.show_error_message("Ошибка", f"Произошла ошибка при удалении студента: {e}")
                finally:
                    #session.close()
                    pass
            else:
                self.show_message("Удалить студента", "Нет зарегистрированных студентов.")

    def search_student(self):
        student_name, ok = QInputDialog.getText(self, "Поиск студента", "Введите имя студента:")
        if ok and student_name:
            student = session.query(Student).filter(Student.name.ilike(student_name)).first()
            if student:
                self.show_message("Поиск студента", f"Студент {student.name} найден. Группа: {student.group}")
            else:
                self.show_message("Поиск студента", f"Студент {student_name} не найден.")

    def edit_grades(self):
        students = session.query(Student).all()

        if students:
            student_names = [student.name for student in students]
            student_name, ok = QInputDialog.getItem(self, "Редактировать оценки студента", "Выберите студента:",
                                                    student_names, 0, False)

            if ok and student_name:
                student = session.query(Student).filter_by(name=student_name).first()

                if student:
                    grades = session.query(Grades).filter_by(student_id=student.id).all()

                    if grades:
                        grade_subject, ok = QInputDialog.getText(self, "Редактировать оценки студента",
                                                                 "Введите предмет:", text="")

                        if ok and grade_subject:
                            grade_to_edit = session.query(Grades).filter_by(student_id=student.id,
                                                                            subject=grade_subject).first()

                            if grade_to_edit:
                                new_grade, ok = QInputDialog.getInt(self, "Редактировать оценки студента",
                                                                    "Введите новую оценку:",
                                                                    value=grade_to_edit.grade)

                                if ok:
                                    grade_to_edit.grade = new_grade

                                    try:
                                        session.commit()
                                        self.show_message("Редактировать оценки студента",
                                                          "Оценка успешно обновлена.")
                                    except Exception as e:
                                        session.rollback()
                                        self.show_error_message("Ошибка",
                                                                f"Произошла ошибка при редактировании оценки: {e}")
                            else:
                                self.show_error_message("Ошибка", f"Оценка по предмету {grade_subject} не найдена.")
                    else:
                        self.show_message("Редактировать оценки студента", f"У студента {student_name} нет оценок.")
                else:
                    self.show_error_message("Ошибка", f"Студент {student_name} не найден.")
            else:
                self.show_message("Редактировать оценки студента", "Нет зарегистрированных студентов.")

    def edit_student(self):
        students = session.query(Student).all()

        if students:
            student_names = [student.name for student in students]
            student_name, ok = QInputDialog.getItem(self, "Редактировать данные студента", "Выберите студента:",
                                                    student_names, 0, False)

            if ok and student_name:
                student_to_edit = session.query(Student).filter_by(name=student_name).first()

                if student_to_edit:
                    new_name, ok = QInputDialog.getText(self, "Редактировать данные студента",
                                                        "Введите новое имя студента:", text=student_to_edit.name)

                    if ok and new_name:
                        student_to_edit.name = new_name

                        new_education_form, ok = QInputDialog.getText(self, "Редактировать данные студента",
                                                                      "Введите новую форму обучения:",
                                                                      text=student_to_edit.education_form)

                        if ok and new_education_form:
                            student_to_edit.education_form = new_education_form

                            new_course, ok = QInputDialog.getInt(self, "Редактировать данные студента",
                                                                 "Введите новый курс:",
                                                                 value=student_to_edit.course)

                            if ok:
                                student_to_edit.course = new_course

                                try:
                                    session.commit()
                                    self.show_message("Редактировать данные студента",
                                                      "Данные студента успешно обновлены.")
                                except Exception as e:
                                    session.rollback()
                                    self.show_error_message("Ошибка",
                                                            f"Произошла ошибка при редактировании студента: {e}")
                    else:
                        self.show_error_message("Ошибка", f"Студент {student_name} не найден.")
                else:
                    self.show_error_message("Ошибка", f"Студент {student_name} не найден.")
            else:
                self.show_message("Редактировать данные студента", "Нет зарегистрированных студентов.")

    def save_changes(self):
        try:
            session.commit()
            self.show_message("Редактировать данные студента", "Данные студента успешно обновлены.")
        except Exception as e:
            session.rollback()
            self.show_error_message("Ошибка", f"Произошла ошибка при редактировании студента: {e}")

    def import_grades_to_excel(self):
        workbook = openpyxl.Workbook()
        sheet = workbook.active

        sheet['A1'] = 'Студент'
        sheet['B1'] = 'Предмет'
        sheet['C1'] = 'Оценка'

        students = session.query(Student).all()

        row = 2
        for student in students:
            for grade in student.grades:
                sheet.cell(row=row, column=1, value=student.name)
                sheet.cell(row=row, column=2, value=grade.subject)
                sheet.cell(row=row, column=3, value=grade.grade)
                row += 1

        workbook.save('grades.xlsx')
        self.show_message("Импорт в Excel", "Данные успешно импортированы в файл grades.xlsx")



if __name__ == "__main__":
    app = QApplication([])
    user = User(username="test", role="employee")
    window = Teacher(user)
    window.show()
    app.exec()