from sqlalchemy import create_engine, Column, String, Integer, ForeignKey
from sqlalchemy.orm import declarative_base, relationship, sessionmaker

Base = declarative_base()
engine = create_engine("sqlite:///students.db")
Session = sessionmaker(bind=engine)
session = Session()

class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String, unique=True, nullable=False)
    password = Column(String, nullable=False)
    role = Column(String, nullable=False)

    students = relationship('Student', back_populates='curator', foreign_keys='Student.curator_id')
    curators = relationship('Student', back_populates='student', foreign_keys='Student.student_id')
    teachers = relationship('Teacher', back_populates='user', foreign_keys='Teacher.user_id')

class Student(Base):
    __tablename__ = 'students'
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    group = Column(Integer, nullable=True)
    email = Column(String, nullable=False)
    course = Column(String, nullable=False)
    education_form = Column(String, nullable=False)
    curator_id = Column(Integer, ForeignKey('users.id'))
    curator = relationship('User', foreign_keys=[curator_id], back_populates='students')
    student_id = Column(Integer, ForeignKey('users.id'))
    student = relationship('User', foreign_keys=[student_id], back_populates='curators')
    phone_number = Column(Integer, nullable=False)
    grades = relationship('Grades', backref='student')

class Teacher(Base):
    __tablename__ = 'teachers'
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    email = Column(String, nullable=False)
    phone_number = Column(Integer, nullable=False)
    user_id = Column(Integer, ForeignKey('users.id'))
    user = relationship('User', foreign_keys=[user_id], back_populates='teachers')

class Grades(Base):
    __tablename__ = 'grades'
    id = Column(Integer, primary_key=True, autoincrement=True)
    student_id = Column(Integer, ForeignKey('students.id'))
    subject = Column(String, nullable=False)
    grade = Column(Integer, nullable=False)

Base.metadata.create_all(engine)

student1 = Student(name='Иванов Иван', group=1, email='ivanov@example.com', course='1', education_form='Очная', phone_number=1234567890)
student2 = Student(name='Петров Петр', group=2, email='petrov@example.com', course='2', education_form='Заочная', phone_number=9876543210)
student3 = Student(name='Харитонова Алиса', group=3, email='kharitonova@example.com', course='3', education_form='Заочная', phone_number=987743210)
student4 = Student(name='Смирнова Екатерина', group=1, email='smirnova@example.com', course='1', education_form='Очная', phone_number=1234567891)
student5 = Student(name='Козлов Дмитрий', group=2, email='kozlov@example.com', course='2', education_form='Заочная', phone_number=9876543211)

teacher1 = Teacher(name='Сидоров Сидор', email='sidorov@example.com', phone_number=5555555555)
teacher2 = Teacher(name='Петрова Анна', email='petrova@example.com', phone_number=6666666666)
teacher3 = Teacher(name='Иванова Елена', email='ivanova@example.com', phone_number=7777777777)

grade1 = Grades(subject='Математика', grade=5)
grade2 = Grades(subject='Физика', grade=4)
grade3 = Grades(subject='Информатика', grade=3)
grade4 = Grades(subject='Химия', grade=4)
grade5 = Grades(subject='Литература', grade=5)

student1.grades.append(grade1)
student1.grades.append(grade2)

student2.grades.append(grade3)
student2.grades.append(grade4)
student2.grades.append(grade5)

student3.grades.append(grade1)

student4.grades.append(grade2)

student5.grades.append(grade3)
student5.grades.append(grade4)
student5.grades.append(grade5)

session.add_all([student1, student2, student3, student4, student5, teacher1, teacher2, teacher3, grade1, grade2, grade3, grade4, grade5])
session.commit()
