from PyQt6.QtWidgets import QDialog, QLabel, QVBoxLayout, QPushButton, QMessageBox, QInputDialog, QApplication
from models import session, Grades


class Student(QDialog):
    def __init__(self, user):
        super().__init__()

        self.setWindowTitle('Учет студента в вузе - Режим студента')
        self.setFixedSize(400, 200)
        self.user = user
        self.adjustSize()
        self.move_center()

        layout = QVBoxLayout()

        welcome_label = QLabel(f"Добро пожаловать, {user.username}!")
        self.welcome_label = welcome_label

        welcome_label = QLabel(f"Добро пожаловать, {user.username}!")
        change_email_btn = QPushButton("Изменить почту")
        change_name_btn = QPushButton("Изменить имя")
        change_education_form_btn = QPushButton("Изменить форму обучения")
        view_grades_btn = QPushButton("Просмотреть оценки по предмету")

        change_email_btn.clicked.connect(self.change_email)
        change_name_btn.clicked.connect(self.change_name)
        change_education_form_btn.clicked.connect(self.change_education_form)
        view_grades_btn.clicked.connect(self.view_grades_by_subject)

        layout.addWidget(welcome_label)
        layout.addWidget(change_email_btn)
        layout.addWidget(change_name_btn)
        layout.addWidget(change_education_form_btn)
        layout.addWidget(view_grades_btn)

        self.setLayout(layout)

    def change_email(self):
        new_email, ok = QInputDialog.getText(self, "Изменить почту", "Введите новую почту:")

        if ok and new_email:
            try:
                self.user.email_address = new_email
                session.commit()

                self.show_message("Изменить почту", "Почта успешно изменена.")
                self.welcome_label.setText(f"Почта: {self.user.email_address}")

            except Exception as e:
                session.rollback()
                self.show_error_message("Ошибка", f"Произошла ошибка: {e}")

            finally:
                session.close()

    def view_grades_by_subject(self):
        subject, ok = QInputDialog.getText(self, "Просмотреть оценки по предмету", "Введите предмет:")

        if ok and subject:
            try:
                grades = session.query(Grades).filter_by(student_id=self.user.id, subject=subject).all()
                if grades:
                    grades_str = "\n".join([f"Оценка: {grade.grade}" for grade in grades])
                    self.show_message("Просмотреть оценки по предмету", f"Оценки по предмету {subject}:\n{grades_str}")
                else:
                    self.show_message("Просмотреть оценки по предмету", f"Нет оценок по предмету {subject}")

            except Exception as e:
                self.show_error_message("Ошибка", f"Произошла ошибка: {e}")

            finally:
                session.close()

    def change_education_form(self):
        new_edication_form, ok = QInputDialog.getText(self, "Изменить форму обучения", "Введите новую форму обучения:")

        if ok and new_edication_form:
            try:
                self.user.fullname = new_edication_form
                session.commit()

                self.show_message("Изменить форму обучения", "Форма обучения успешно изменена.")
                self.welcome_label.setText(f"Имя: {self.user.fullname}")

            except Exception as e:
                session.rollback()
                self.show_error_message("Ошибка", f"Произошла ошибка: {e}")

            finally:
                session.close()

    def change_name(self):
        new_name, ok = QInputDialog.getText(self, "Изменить имя", "Введите новое имя:")

        if ok and new_name:
            try:
                self.user.fullname = new_name
                session.commit()

                self.show_message("Изменить имя", "Имя успешно изменено.")
                self.welcome_label.setText(f"Имя: {self.user.fullname}")

            except Exception as e:
                session.rollback()
                self.show_error_message("Ошибка", f"Произошла ошибка: {e}")

            finally:
                session.close()

    def move_center(self):
        frame_gm = self.frameGeometry()
        screen = QApplication.primaryScreen().availableGeometry()
        frame_gm.moveCenter(screen.center())
        self.move(frame_gm.topLeft())

    def show_message(self, title, message):
        msg_box = QMessageBox()
        msg_box.setIcon(QMessageBox.Icon.Information)
        msg_box.setWindowTitle(title)
        msg_box.setText(message)
        msg_box.exec()

    def show_error_message(self, title, message):
        msg_box = QMessageBox()
        msg_box.setIcon(QMessageBox.Icon.Critical)
        msg_box.setWindowTitle(title)
        msg_box.setText(message)
        msg_box.exec()